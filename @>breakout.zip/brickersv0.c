#include <SDL2/SDL.h>
#include <stdbool.h>

#define WINDOW_WIDTH 600
#define WINDOW_HEIGHT 400
#define PADDLE_WIDTH 80
#define PADDLE_HEIGHT 10
#define BALL_SIZE 10
#define BRICK_ROWS 5
#define BRICK_COLUMNS 10
#define BRICK_WIDTH (WINDOW_WIDTH / BRICK_COLUMNS)
#define BRICK_HEIGHT 20

typedef struct {
    float x, y;
    float dx, dy;
} Ball;

typedef struct {
    float x, y;
} Paddle;

typedef struct {
    float x, y;
    bool destroyed;
} Brick;

void draw_rect(SDL_Renderer *renderer, float x, float y, float w, float h) {
    SDL_Rect rect = { (int)x, (int)y, (int)w, (int)h };
    SDL_RenderFillRect(renderer, &rect);
}

int main(int argc, char *argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Window *win = SDL_CreateWindow("Breakout", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    if (win == NULL) {
        printf("SDL_CreateWindow Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Renderer *ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (ren == NULL) {
        SDL_DestroyWindow(win);
        printf("SDL_CreateRenderer Error: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    Paddle paddle = { WINDOW_WIDTH / 2 - PADDLE_WIDTH / 2, WINDOW_HEIGHT - 20 };
    Ball ball = { WINDOW_WIDTH / 2 - BALL_SIZE / 2, WINDOW_HEIGHT / 2 - BALL_SIZE / 2, 0.3f, -0.3f };
    Brick bricks[BRICK_ROWS][BRICK_COLUMNS];

    for (int i = 0; i < BRICK_ROWS; i++) {
        for (int j = 0; j < BRICK_COLUMNS; j++) {
            bricks[i][j].x = j * BRICK_WIDTH;
            bricks[i][j].y = i * BRICK_HEIGHT;
            bricks[i][j].destroyed = false;
        }
    }

    bool quit = false;
    SDL_Event e;

    while (!quit) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                quit = true;
            } else if (e.type == SDL_MOUSEMOTION) {
                SDL_MouseMotionEvent motion = e.motion;
                paddle.x = motion.x - PADDLE_WIDTH / 2;
            }
        }

        ball.x += ball.dx;
        ball.y += ball.dy;

        if (ball.x <= 0 || ball.x + BALL_SIZE >= WINDOW_WIDTH) {
            ball.dx = -ball.dx;
        }
        if (ball.y <= 0) {
            ball.dy = -ball.dy;
        }
        if (ball.y + BALL_SIZE >= WINDOW_HEIGHT) {
            ball.x = WINDOW_WIDTH / 2 - BALL_SIZE / 2;
            ball.y = WINDOW_HEIGHT / 2 - BALL_SIZE / 2;
            ball.dy = -ball.dy;
        }

        if (ball.x + BALL_SIZE >= paddle.x && ball.x <= paddle.x + PADDLE_WIDTH && ball.y + BALL_SIZE >= paddle.y) {
            ball.dy = -ball.dy;
        }

        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLUMNS; j++) {
                Brick *brick = &bricks[i][j];
                if (!brick->destroyed) {
                    if (ball.x + BALL_SIZE >= brick->x && ball.x <= brick->x + BRICK_WIDTH && ball.y + BALL_SIZE >= brick->y && ball.y <= brick->y + BRICK_HEIGHT) {
                        brick->destroyed = true;
                        ball.dy = -ball.dy;
                    }
                }
            }
        }

        SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
        SDL_RenderClear(ren);

        SDL_SetRenderDrawColor(ren, 255, 255, 255, 255);
        draw_rect(ren, paddle.x, paddle.y, PADDLE_WIDTH, PADDLE_HEIGHT);
        draw_rect(ren, ball.x, ball.y, BALL_SIZE, BALL_SIZE);

        for (int i = 0; i < BRICK_ROWS; i++) {
            for (int j = 0; j < BRICK_COLUMNS; j++) {
                if (!bricks[i][j].destroyed) {
                    draw_rect(ren, bricks[i][j].x, bricks[i][j].y, BRICK_WIDTH, BRICK_HEIGHT);
                }
            }
        }

        SDL_RenderPresent(ren);
    }

    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    SDL_Quit();

    return 0;
}
